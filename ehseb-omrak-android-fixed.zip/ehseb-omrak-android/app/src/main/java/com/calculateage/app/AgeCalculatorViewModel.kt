package com.calculateage.app

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.util.Calendar

data class CalculationResult(
    val birthYear: Int,
    val ageInYears: Int,
    val generation: String,
    val decade: String
)

data class CalculatorUiState(
    val inputDigits: String = "",
    val hasBirthdayPassed: Boolean = true,
    val errorMessage: String? = null,
    val result: CalculationResult? = null
)

class AgeCalculatorViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(CalculatorUiState())
    val uiState: StateFlow<CalculatorUiState> = _uiState.asStateFlow()

    fun onInputChanged(raw: String) {
        val normalized = normalizeDigits(raw)
        // السماح برقمين فقط ورفض أي حروف أو رموز
        if (normalized.length <= 2 && normalized.all { it.isDigit() }) {
            _uiState.update {
                it.copy(
                    inputDigits = normalized,
                    errorMessage = null
                )
            }
        }
    }

    fun setBirthdayPassed(passed: Boolean) {
        _uiState.update { it.copy(hasBirthdayPassed = passed) }
        if (_uiState.value.result != null) {
            calculate()
        }
    }

    fun calculate() {
        val input = _uiState.value.inputDigits.trim()

        if (input.isEmpty()) {
            _uiState.update { it.copy(errorMessage = "اكتب آخر رقمين من سنة ميلادك") }
            return
        }

        if (input.length == 1) {
            _uiState.update { it.copy(errorMessage = "يجب إدخال رقمين كاملين (مثال: 05 أو 85)") }
            return
        }

        if (!input.all { it.isDigit() }) {
            _uiState.update { it.copy(errorMessage = "أرقام فقط بدون حروف أو رموز") }
            return
        }

        // تطبيق القاعدة المحددة بدقة:
        // - إذا كان الرقم 00 فالسنة هي 2000
        // - من 01 إلى 99 أضف الرقم إلى 1900
        val birthYear = if (input == "00") {
            2000
        } else {
            1900 + input.toInt()
        }

        val currentYear = Calendar.getInstance().get(Calendar.YEAR)

        if (birthYear > currentYear) {
            _uiState.update { it.copy(errorMessage = "سنة الميلاد لا يمكن أن تكون في المستقبل") }
            return
        }

        // حساب العمر مع مراعاة ما إذا كان عيد الميلاد قد مر هذا العام
        val ageInYears = if (_uiState.value.hasBirthdayPassed) {
            currentYear - birthYear
        } else {
            currentYear - birthYear - 1
        }

        val generation = when {
            birthYear in 1997..2000 -> "جيل زد (Gen Z)"
            birthYear in 1981..1996 -> "جيل الألفية (Millennials)"
            birthYear in 1965..1980 -> "الجيل إكس (Gen X)"
            birthYear in 1946..1964 -> "جيل طفرة المواليد (Boomers)"
            else -> "الجيل الكلاسيكي"
        }

        val decade = when {
            birthYear == 2000 -> "مطلع الألفية الثانية"
            else -> "حقبة الـ " + ((birthYear % 100) / 10 * 10) + "ات"
        }

        _uiState.update {
            it.copy(
                errorMessage = null,
                result = CalculationResult(
                    birthYear = birthYear,
                    ageInYears = ageInYears,
                    generation = generation,
                    decade = decade
                )
            )
        }
    }

    fun reset() {
        _uiState.value = CalculatorUiState()
    }

    private fun normalizeDigits(str: String): String {
        val arabicNumbers = charArrayOf('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩')
        var result = str
        arabicNumbers.forEachIndexed { index, c ->
            result = result.replace(c, ('0' + index))
        }
        return result
    }
}
